# pytest 18件

`18/18`は質問正解数ではなく、コードの入力分離、代表Executor、OCR、ZIP安全性、Office構造解析を確認するpytestテスト数です。

今回追加したテスト:

17. `test_highlight_intersections_use_full_row_and_column_bands`
   - 黄色の全行バンドと全列バンドの交点だけを抽出し、同じ行にある通常の黄色セルを誤採用しないことを確認します。
18. `test_f1_difference_uses_rounding_not_truncation`
   - F1差を8桁で切り捨てず、通常の四捨五入で`0.09619113`にすることを確認します。

実行:

```bash
python -m pytest -q
```


## Second audit additions
- displayed rank mortality table extraction
- contract bold-field separator formatting
- Total: 20/20 passed
