"""Deterministic executor implementations."""
