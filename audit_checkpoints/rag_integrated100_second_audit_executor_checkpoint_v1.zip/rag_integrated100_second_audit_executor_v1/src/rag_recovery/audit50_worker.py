from __future__ import annotations
import argparse,json,os,time,traceback
from dataclasses import asdict
from pathlib import Path
from .executors.audit_generalization import AuditGeneralizationExecutor
from .executors.remaining50_generalization import Remaining50GeneralizationExecutor
from .models import QueryPlan,Question
from .runner import RecoveryRunner
from .store import DocumentStore

def main():
 p=argparse.ArgumentParser();p.add_argument('--prepared-root',required=True);p.add_argument('--index',type=int,required=True);p.add_argument('--question',required=True);p.add_argument('--output-json',required=True);a=p.parse_args()
 t0=time.perf_counter(); payload={'index':a.index,'question':a.question}
 try:
  store=DocumentStore(Path(a.prepared_root)); store_s=time.perf_counter()-t0
  q=Question('test',a.index,a.question,())
  t1=time.perf_counter(); rr=Remaining50GeneralizationExecutor().execute(q,QueryPlan('remaining50_generalization'),store)
  remaining_elapsed=time.perf_counter()-t1
  if rr.answered:
   r=rr; route='remaining50_generalization'; audit_elapsed=0.0; trace={'remaining50_route':True,'audit_route':False,'base_route':False}
  else:
   t2=time.perf_counter(); ar=AuditGeneralizationExecutor().execute(q,QueryPlan('audit_generalization'),store)
   audit_elapsed=time.perf_counter()-t2
   if ar.answered:
    r=ar; route='audit_generalization'; trace={'remaining50_abstain_reason':rr.reason,'remaining50_diagnostics':rr.diagnostics,'remaining50_elapsed_seconds':remaining_elapsed,'audit_route':True,'base_route':False}
   else:
    t3=time.perf_counter(); runner=RecoveryRunner(Path(a.prepared_root),min_confidence=.80,phase='phase123',fact_catalog=None);r,base_trace=runner.solve(q); base_elapsed=time.perf_counter()-t3;route='base_recovery'
    trace={'remaining50_abstain_reason':rr.reason,'remaining50_diagnostics':rr.diagnostics,'remaining50_elapsed_seconds':remaining_elapsed,'audit_abstain_reason':ar.reason,'audit_diagnostics':ar.diagnostics,'base_trace':base_trace,'base_elapsed_seconds':base_elapsed}
  payload.update(answered=bool(r.answered),answer=r.answer if r.answered else 'わからない',confidence=float(r.confidence),method=r.method,reason=r.reason,route=route,evidence=[asdict(e) for e in r.evidence],diagnostics=r.diagnostics,trace=trace,store_seconds=store_s,audit_elapsed_seconds=audit_elapsed,manifest_files=len(store.records),projects=len(store.projects))
 except Exception as e:
  payload.update(answered=False,answer='わからない',confidence=0.0,method='exception',reason=repr(e),route='exception',evidence=[],diagnostics={'traceback':traceback.format_exc()},trace={},store_seconds=0.0,audit_elapsed_seconds=0.0,manifest_files=0,projects=0)
 payload['elapsed_seconds']=round(time.perf_counter()-t0,6)
 out=Path(a.output_json);out.parent.mkdir(parents=True,exist_ok=True);tmp=out.with_suffix(out.suffix+'.tmp');tmp.write_text(json.dumps(payload,ensure_ascii=False,default=str),encoding='utf-8');os.replace(tmp,out);os._exit(0)
if __name__=='__main__':main()
