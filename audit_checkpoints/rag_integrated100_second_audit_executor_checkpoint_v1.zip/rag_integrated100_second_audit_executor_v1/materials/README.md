# Runtime source

完全コールドスタートでは、未加工の `share.zip` をこのディレクトリへ `share.zip` として配置します。
この軽量Executor統合チェックポイントには元資料を同梱していません。
